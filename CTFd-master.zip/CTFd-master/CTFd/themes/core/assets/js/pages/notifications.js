import "./main";
import $ from "jquery";
import CTFd from "../CTFd";
import { clear_notification_counter } from "../utils";

$(() => {
  clear_notification_counter();
});
